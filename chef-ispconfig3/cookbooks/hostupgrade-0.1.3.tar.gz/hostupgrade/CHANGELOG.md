hostupgrade CHANGELOG
=================

0.1.3
-----
- stajkowski - Support for Chef-Solo.  What I have done instead was to touch a file in /tmp as a flag for the first run only, this will only happen for chef-solo instead of saving the node attributes to chef-server.

- - -

0.1.2
-----
- stajkowski - Fix run update and upgrade to operate the same with first-run.

- - -

0.1.1
-----
- stajkowski - Initial release.

- - -
